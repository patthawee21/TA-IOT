// โปรแกรมคำนวณการใช้น้ำของพืช
// ETo = Kp * Ep
// ETc = ETo * Kc

const float Kp = 0.75;

const int NUM_PLANTS = 17;


// ชื่อพืชภาษาอังกฤษ
String plantName[NUM_PLANTS] = {
  "Lantana",
  "Ixora",
  "Gardenia",
  "Forget me not",
  "Marigold",
  "Cosmos",
  "Globe amaranth",
  "Rain tree",
  "Silver button",
  "Neem",
  "Jacaranda",
  "Pink trumpet tree",
  "Indian cork tree",
  "Golden trumpet tree",
  "Devil tree",
  "Guava",
  "RD43 rice"
};


// ค่า Kc
// Kc ini = เริ่มเติบโต / เริ่มงอกจากเมล็ด
float Kc_ini[NUM_PLANTS] = {
  0.80, 1.10, 1.10, 0.70, 0.70, 0.70, 0.80,
  0.50, 0.65, 0.65, 0.60, 0.40, 0.60, 0.40,
  0.65, 0.65, 1.05
};

// Kc mid = ระยะเจริญเติบโตเต็มที่ / ใช้น้ำมากสุด
float Kc_mid[NUM_PLANTS] = {
  0.85, 1.15, 1.15, 1.00, 1.00, 1.00, 0.85,
  1.10, 0.70, 0.70, 0.95, 1.10, 0.95, 1.10,
  0.70, 0.60, 1.20
};

// Kc end = ระยะเริ่มชรา / ปลายการเจริญเติบโต
float Kc_end[NUM_PLANTS] = {
  0.85, 1.15, 1.15, 0.95, 0.95, 0.95, 0.85,
  0.65, 0.70, 0.70, 0.75, 0.45, 0.75, 0.45,
  0.70, 0.65, 0.75
};


// ค่า Ep กรุงเทพมหานคร (mm/day)
float Ep[12] = {
  3.82,  // January
  4.93,  // February
  5.26,  // March
  4.74,  // April
  4.45,  // May
  4.27,  // June
  3.24,  // July
  3.65,  // August
  3.37,  // September
  3.37,  // October
  3.80,  // November
  3.76   // December
};

String monthName[12] = {
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December"
};


// ค้นหาพืช
int findPlant(String input) {

  input.trim();
  input.toLowerCase();

  for (int i = 0; i < NUM_PLANTS; i++) {

    String name = plantName[i];
    name.toLowerCase();

    if (input == name) {
      return i;
    }
  }

  return -1;
}


// เลือกค่า Kc ตามระยะการเจริญเติบโต
float getKc(int plant, String stage) {

  stage.toLowerCase();
  stage.trim();

  if (stage == "ini") {
    return Kc_ini[plant];
  }

  else if (stage == "mid") {
    return Kc_mid[plant];
  }

  else if (stage == "end") {
    return Kc_end[plant];
  }

  return -1;
}


void setup() {

  Serial.begin(9600);

  Serial.println();
  Serial.println("==========================================");
  Serial.println("   PLANT WATER REQUIREMENT CALCULATOR");
  Serial.println("==========================================");

  Serial.println();
  Serial.println("Available plants:");

  for (int i = 0; i < NUM_PLANTS; i++) {
    Serial.println(plantName[i]);
  }

  Serial.println();
  Serial.println("Enter plant name in English:");
}


void loop() {

  
  // 1. รับชื่อพืช

  if (Serial.available() > 0) {

    String inputPlant = Serial.readStringUntil('\n');
    inputPlant.trim();

    int plant = findPlant(inputPlant);

    if (plant == -1) {

      Serial.println();
      Serial.println("Plant not found!");
      Serial.println("Please enter the plant name again:");

      return;
    }

    Serial.println();
    Serial.print("Selected plant: ");
    Serial.println(plantName[plant]);

   
    // 2. รับเดือน
    Serial.println();
    Serial.println("Enter month (1-12):");

    while (Serial.available() == 0) {
      // รอข้อมูล
    }

    int month = Serial.parseInt();

    while (Serial.available() > 0) {
      Serial.read();
    }

    if (month < 1 || month > 12) {

      Serial.println("Invalid month!");
      Serial.println("Please enter month 1-12:");

      return;
    }

    
    // 3. รับระยะการเจริญเติบโต
    Serial.println();
    Serial.println("Enter growth stage:");
    Serial.println("ini = Beginning growth / germination");
    Serial.println("mid = Full growth / maximum water use");
    Serial.println("end = Aging / late growth");

    while (Serial.available() == 0) {
      // รอข้อมูล
    }

    String stage = Serial.readStringUntil('\n');
    stage.trim();
    stage.toLowerCase();

   
    // 4. เลือก Kc
    float kc = getKc(plant, stage);

    if (kc == -1) {

      Serial.println();
      Serial.println("Invalid growth stage!");
      Serial.println("Please use ini, mid or end.");

      return;
    }

  
    // 5. ค่า Ep
    float ep = Ep[month - 1];

    // 6. คำนวณ ETo
    float eto = Kp * ep;

    // 7. คำนวณ ETc
    float etc = eto * kc;

    // 8. แสดงผล
    Serial.println();
    Serial.println("==========================================");
    Serial.println("                 RESULT");
    Serial.println("==========================================");

    Serial.print("Plant        : ");
    Serial.println(plantName[plant]);

    Serial.print("Month        : ");
    Serial.print(month);
    Serial.print(" (");
    Serial.print(monthName[month - 1]);
    Serial.println(")");

    Serial.print("Growth stage : ");
    Serial.println(stage);

    Serial.print("Kp           : ");
    Serial.println(Kp, 2);

    Serial.print("Ep           : ");
    Serial.print(ep, 2);
    Serial.println(" mm/day");

    Serial.print("Kc           : ");
    Serial.println(kc, 2);

    Serial.println("------------------------------------------");

    Serial.print("ETo = Kp x Ep = ");
    Serial.print(eto, 2);
    Serial.println(" mm/day");

    Serial.print("ETc = ETo x Kc = ");
    Serial.print(etc, 2);
    Serial.println(" mm/day");

    Serial.println("==========================================");

    Serial.println();
    Serial.println("Enter another plant name in English:");
  }
}